#ifndef QUEENTOWER_H
#define QUEENTOWER_H
#include"tower.h"
#include"buildtowericon.h"

class QueenBullet;

class QueenTower: public Tower
{
public:
    QueenTower(QGraphicsItem * parent = 0);
    ~QueenTower();
    virtual void attack_Enemy();
    virtual void upgrade();
    void draw();
    void Enemy_release(Enemy * enemy);
    virtual void mousePressEvent(QGraphicsSceneMouseEvent *event);
    virtual void getblack();

public slots:
    virtual void check_EnemyInRange();

private:
    QueenBullet * bullet;

};

#endif // QUEENTOWER_H
