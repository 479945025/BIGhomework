#ifndef SLOWTOWER_H
#define SLOWTOWER_H
#include"tower.h"
#include"buildtowericon.h"

class SlowTower: public Tower
{
public:
    SlowTower(QGraphicsItem * parent = 0);
    virtual void attack_Enemy();
    virtual void upgrade();
    virtual void getblack();
private:
    int slow_rate;
};

#endif // SLOWTOWER_H
