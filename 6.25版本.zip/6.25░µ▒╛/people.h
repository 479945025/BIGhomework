#ifndef PEOPLE_H
#define PEOPLE_H

#include <QWidget>

namespace Ui {
class people;
}

class people : public QWidget
{
    Q_OBJECT

public:
    explicit people(QWidget *parent = nullptr);
    ~people();
    void paintEvent(QPaintEvent *);

private slots:
   void on_pushButton_clicked();
   void receivepeople();

signals:
   void startshow2();

private:
    Ui::people *ui;
};

#endif // PEOPLE_H
