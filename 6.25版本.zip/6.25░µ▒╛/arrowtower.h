#ifndef ARROWTOWER_H
#define ARROWTOWER_H
#include"tower.h"
#include"buildtowericon.h"

class ArrowTower: public Tower{
public:
    ArrowTower(QGraphicsItem * parent = 0);

    virtual void attack_Enemy();
    virtual void upgrade();
    virtual void getblack();
};

#endif // ARROWTOWER_H
