#include "blacktower.h"

BlackTower::BlackTower(QGraphicsItem * parent):Tower (parent)
{

}

void BlackTower::mousePressEvent(QGraphicsSceneMouseEvent *event){

}

void BlackTower::attack_Enemy(){

}

void BlackTower::upgrade(){

}

void BlackTower::getblack(){

}
