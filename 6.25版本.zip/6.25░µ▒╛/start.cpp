#include "start.h"
#include "ui_start.h"
#include <QPainter>
QMediaPlayer * player = new QMediaPlayer;
QMediaPlayer * playerstory = new QMediaPlayer;

start::start(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::start)
{
    ui->setupUi(this);
   // connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player->setMedia(QUrl("qrc:/music/music/Start.mp3"));
    player->setVolume(30);
    player->play();
}

start::~start()
{
    delete ui;
}
void start::paintEvent(QPaintEvent *)
{
    QPixmap background(":/scene/images/scene/startscene.jpg");
    QPainter painter(this);
    painter.drawPixmap(0,0,background);
}

void start::on_pushButton_clicked()
{
    this->hide();
    emit showmainwindow();
}

void start::receiveshow()
{
    this->show();
}

void start::on_pushButton_2_clicked()
{
    this->hide();
    playerstory->setMedia(QUrl("qrc:/music/music/Story.mp3"));
    playerstory->setVolume(30);
    playerstory->play();
    player->stop();
    emit showstory();

}
void start::receiveshow1()
{
    this->show();
}
void start::on_pushButton_3_clicked()
{
    this->hide();
    emit showpeople();
}
void start::receiveshow2()
{
    this->show();
}

void start::on_pushButton_4_clicked()
{
    this->hide();
    emit showplay();
}
void start::receiveshow3()
{
    this->show();
}
