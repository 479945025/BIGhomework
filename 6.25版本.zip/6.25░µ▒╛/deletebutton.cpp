#include "deletebutton.h"
#include"game.h"

extern Game * game;

DeleteButton::DeleteButton(QGraphicsItem *parent): QGraphicsPixmapItem(parent){
    setPixmap(QPixmap(":/scene/images/scene/delete2_60x60.png"));
}

void DeleteButton::mousePressEvent(QGraphicsSceneMouseEvent *event){
    tower->towerposition->setTower_Exist(false);
    game->scene->removeItem(tower);
    game->scene->removeItem(game->upgradebutton);
    game->scene->removeItem(this);

    game->deletebutton = nullptr;
    game->upgradebutton = nullptr;
    delete tower;
}
