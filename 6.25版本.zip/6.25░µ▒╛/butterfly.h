#ifndef BUTTERFLY_H
#define BUTTERFLY_H
#include<enemy.h>
#include <QGraphicsPixmapItem>
#include <QObject>

class Butterfly: public Enemy
{
public:
    Butterfly(QGraphicsItem *parent=nullptr);
    ~Butterfly();
};

#endif // BUTTERFLY_H
