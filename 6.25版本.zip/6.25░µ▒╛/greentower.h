#ifndef GREENTOWER_H
#define GREENTOWER_H
#include"tower.h"
#include"buildtowericon.h"

class GreenTower: public Tower
{
public:
    GreenTower(QGraphicsItem * parent = 0);
    virtual void attack_Enemy();
    virtual void upgrade();
    virtual void getblack();

public slots:
    virtual void check_EnemyInRange();
private:
    int weak;
};

#endif // GREENTOWER_H
