#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include"towerposition.h"
//
#include<QLabel>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
     void paintEvent(QPaintEvent *);
//
     QLabel * label;
private slots:
    void on_pushButton_clicked();
    void receivechoose();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    //jiaru
    void receivestory();
signals:
    void startshow();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
