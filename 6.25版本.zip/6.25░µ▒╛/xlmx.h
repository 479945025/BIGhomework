#ifndef XLMX_H
#define XLMX_H

#include <QWidget>

namespace Ui {
class xlmx;
}

class xlmx : public QWidget
{
    Q_OBJECT

public:
    explicit xlmx(QWidget *parent = nullptr);
    ~xlmx();
    void paintEvent(QPaintEvent *);


private slots:
    void on_pushButton_clicked();
    void receivexlmx();
signals:
    void playshow();

private:
    Ui::xlmx *ui;
};

#endif // XLMX_H
