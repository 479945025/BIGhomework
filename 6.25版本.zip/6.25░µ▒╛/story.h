#ifndef STORY_H
#define STORY_H

#include <QWidget>
#include<QLabel>
namespace Ui {
class story;
}

class story : public QWidget
{
    Q_OBJECT

public:
    explicit story(QWidget *parent = nullptr);
    ~story();
    void paintEvent(QPaintEvent *);
    QLabel * label;
private slots:
   void on_pushButton_clicked();
   void receivestory();

signals:
   void startshow1();

private:
    Ui::story *ui;
};

#endif // STORY_H
