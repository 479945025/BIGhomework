#include "cannontowerbuildicon.h"
#include"game.h"
#include<QtMultimedia/QMediaPlayer>
extern Game * game;



CannonTowerBuildIcon::CannonTowerBuildIcon(QGraphicsItem * parent) : BuildTowerIcon(parent)
{
    setPixmap(QPixmap(":/scene/images/scene/1725-90.png"));
    this->setPos(1725,90);
}

void CannonTowerBuildIcon::mousePressEvent(QGraphicsSceneMouseEvent *event){

    if (!game->build && (game->gold - 300) >= 0){
        game->build = new CannonTower();
        game->setCursor(QString(":/tower/images/tower/xltm_44x66.png"));

    }
}
