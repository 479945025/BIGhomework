#include "starttouch.h"

StartTouch::StartTouch()
{

}
