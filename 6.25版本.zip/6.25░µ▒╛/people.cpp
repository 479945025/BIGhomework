#include "people.h"
#include "ui_people.h"
#include<QPainter>
people::people(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::people)
{
    ui->setupUi(this);
}

people::~people()
{
    delete ui;
}

void people::paintEvent(QPaintEvent *)
{
    QPixmap background(":/scene/images/scene/photo.jpg");
    QPainter painter(this);
    painter.drawPixmap(0,0,background);
}
void people::on_pushButton_clicked()
{
    this->hide();
    emit  startshow2();
}
void people::receivepeople()
{
    this->show();
}
