#include "greentower.h"
#include"game.h"
#include"arrowbullet.h"
#include<QDebug>
#include<QtMath>
#include <QVector2D>
#include"blacktower.h"

extern Game * game;

GreenTower::GreenTower(QGraphicsItem * parent):Tower (parent)
{
    setPixmap(QPixmap(":/tower/images/tower/lmxLv.1_44x66.png"));

    //setPixmap(QPixmap(":/png/queen.png"));
    attacking = false;
    attackRange = 200;
    damage = 50;

    money = 200;
    game->gold -= money;
    center_pos = QPointF(this->pixmap().width()*0.5,this->pixmap().height()*0.5);
    weak = 3;
    attack_desk = QPointF(0,0);
    has_target = false;

    //0.5秒发一次子弹
    QTimer * timer = new QTimer();
    connect(timer,SIGNAL(timeout()),this,SLOT(check_EnemyInRange()));
    timer->start(500);

    //画攻击范围
    attack_area = new QGraphicsEllipseItem(0,0,attackRange*2,attackRange*2,this);
    QPen pen = QPen(Qt::DotLine);
    pen.setColor(Qt::lightGray);
    pen.setWidth(0);
    attack_area->setPen(pen);

    //画攻击范围
    QPointF offsetPoint(this->pixmap().width()*0.5,this->pixmap().height()*0.5);

    attack_area->setPos(offsetPoint + QPointF(-attackRange,-attackRange));
}

void GreenTower::attack_Enemy(){
    Bullet * bullet = new GreenBullet ();

    bullet->setPos(x()+40,y()+40);
    bullet->setInfo(attack_desk,damage,chooseEnemy);

    QLineF ln(QPointF(x()+40,y()+40),attack_desk);
    int angle = -1 * ln.angle();
    bullet->setRotation(angle);

    bullet->move();
    game->scene->addItem(bullet);
}

void GreenTower::upgrade(){
    if(grade >= 3)
        return;

    if((game->gold - 100 * (grade+1)) >= 0){
        grade++;
        if(grade ==2){
            setPixmap(QPixmap(":/tower/images/tower/lmxLv.2_66x88.png"));
            setPos(QPointF(x()-20,y()));
            center_pos = QPointF(this->pixmap().width()*0.5,this->pixmap().height()*0.5);
        }
        else if(grade == 3){
            setPixmap(QPixmap(":/tower/images/tower/lmxLv.3_110x136.png"));
            setPos(QPointF(x()-25,y()));
            center_pos = QPointF(this->pixmap().width()*0.5,this->pixmap().height()*0.5);
        }

        attackRange += 50;
        damage += 50;
        game->gold -= 100;

        game->scene->removeItem(attack_area);
        attack_area = nullptr;
        attack_area = new QGraphicsEllipseItem(0,0,attackRange*2,attackRange*2,this);

        QPen pen = QPen(Qt::DotLine);
        pen.setColor(Qt::lightGray);
        pen.setWidth(0);
        attack_area->setPen(pen);

        QPointF offsetPoint(this->pixmap().width()*0.5,this->pixmap().height()*0.5);
        attack_area->setPos(offsetPoint + QPointF(-attackRange,-attackRange));
    }

}

void GreenTower::check_EnemyInRange(){
    QList<QGraphicsItem*> colliding_items = attack_area->collidingItems();

    double closest_dist = attackRange;
    has_target = false;

    closest_pt = QPointF(0,0);

    for(size_t i = 0,n = colliding_items.size(); i < n; i++){
        Enemy * enemy = dynamic_cast<Enemy *>(colliding_items[i]);
        if(enemy){
            double this_dist = distanceto(colliding_items[i]);
            if(this_dist < closest_dist){
                closest_dist = this_dist;
                closest_pt = colliding_items[i]->pos() + QPointF(0,0);
                chooseEnemy = enemy;
                has_target = true;
                enemy->getweak(weak);
            }
        }
    }

    if(has_target){
        attack_desk = closest_pt;

        chooseEnemy->getAttacked(this);
        attack_Enemy();
    }
    else{
        lostSightOfEnemy();
    }

}

void GreenTower::getblack(){
    black = 1;

    BlackTower * blacktower = new BlackTower();
    blacktower->setPos(QPointF(x()-40,y()));
    blacktower->setPixmap(QPixmap(":/tower/images/tower/glmx_90x126.png"));

    game->scene->addItem(blacktower);
    game->scene->removeItem(this);
    delete this;
}
