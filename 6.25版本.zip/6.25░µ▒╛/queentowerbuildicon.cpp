#include "queentowerbuildicon.h"
#include"game.h"

extern Game * game;

QueenTowerBuildIcon::QueenTowerBuildIcon(QGraphicsItem * parent) : BuildTowerIcon(parent)
{
    setPixmap(QPixmap(":/scene/images/scene/1574-252.png"));
    this->setPos(1574,252);
}

void QueenTowerBuildIcon::mousePressEvent(QGraphicsSceneMouseEvent *event){
    if (!game->build && (game->gold - 200) >= 0){
        game->build = new QueenTower();
        game->setCursor(QString(":/tower/images/tower/nwtm_110x136.png"));
    }

}
