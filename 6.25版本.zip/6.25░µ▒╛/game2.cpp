#include "game2.h"
#include<QGraphicsScene>
#include<qdebug.h>
#include"xiaoyue.h"
#include<QtMultimedia/QMediaPlayer>
#include"game3.h"

extern QMediaPlayer * player2;
extern QMediaPlayer * player3;
extern Game * game;

Game2::Game2():Game (){
    playerHp = 10;
    gold = 1000;
    currentEnemyNum = 0;

    scene = new QGraphicsScene(this);
    scene->setSceneRect(0,0,1884,1200);

    QPixmap map(":/scene/images/scene/background1.jpg");

    points_1<<QPoint(800,0)
            <<QPoint(760,150)
             <<QPoint(650,170)
            <<QPoint(450,200)
             <<QPoint(350,250)
             <<QPoint(250,350)
            <<QPoint(200,450)
             <<QPoint(250,550)
            <<QPoint(570,950)
             <<QPoint(550,1000);

    points_2<<QPoint(800,0)
            <<QPoint(860,120)
             <<QPoint(990,220)
             <<QPoint(1200,400)
             <<QPoint(1250,600)
             <<QPoint(1220,730)
             <<QPoint(1170,850)
             <<QPoint(950,900)
            //<<QPoint()
             <<QPoint(570,950)
             <<QPoint(550,1000);
    QPainter painter(&map);

    setScene(scene);

    setTowerPosition();

    setViewportUpdateMode(QGraphicsView::FullViewportUpdate);

    deletebutton = nullptr;
    upgradebutton = nullptr;
    cursor = nullptr;
    build = nullptr;

    setMouseTracking(true);

    setFixedSize(1884,1200);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    QTimer *timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(drawEnemy()));
    timer->start(1000);


}

void Game2::drawEnemy(){
    if(waves==1&&enemyNum<4){
        Butterfly *butterfly = new Butterfly();
        scene->addItem(butterfly);
        enemyNum++;
        currentEnemyNum++;
    }
    if(waves==1&&enemyNum>=4&&enemyNum<8){
        Spider *spider= new Spider();
        scene->addItem(spider);
        enemyNum++;
        currentEnemyNum++;
        if(enemyNum==8){
            enemyNum=0;
            waves++;
            nextwave=0;
        }
    }
    if(waves==2&&currentEnemyNum==0) nextwave=1;

    if(waves==2&&nextwave){

        if(enemyNum<5){
            Butterfly *butterfly = new Butterfly();
            scene->addItem(butterfly);
            enemyNum++;
            currentEnemyNum++;
        }
        if(enemyNum>=5&&enemyNum<10){
            Spider *spider= new Spider();
            scene->addItem(spider);
            enemyNum++;
            currentEnemyNum++;
            if(enemyNum==10){
                enemyNum=0;
                waves++;
                nextwave=0;
            }
        }
    }
    if(waves==3&&currentEnemyNum==0) nextwave=1;
    if(waves==3&&nextwave){
        if(enemyNum<6){
            Butterfly *butterfly = new Butterfly();
            scene->addItem(butterfly);
            enemyNum++;
            currentEnemyNum++;
        }
        if(enemyNum>=6&&enemyNum<12){
            Spider *spider= new Spider();
            scene->addItem(spider);
            enemyNum++;
            currentEnemyNum++;
            if(enemyNum==12){
                enemyNum=0;
                waves++;
                nextwave=0;
            }
        }
    }

    if(waves==4&&currentEnemyNum==0) nextwave=1;
    if(waves==4&&nextwave){
        if(enemyNum<3){
            Butterfly *butterfly = new Butterfly();
            scene->addItem(butterfly);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=3&&enemyNum<6){
            Spider *spider = new Spider();
            scene->addItem(spider);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=6&&enemyNum<9){
            elf *_elf = new elf();
            scene->addItem(_elf);
            enemyNum++;currentEnemyNum++;
            if(enemyNum==9){
                enemyNum=0;
                waves++;
                nextwave=0;
            }
        }
    }
    if(waves==5&&currentEnemyNum==0) nextwave=1;
    if(waves==5&&nextwave){
        if(enemyNum<4){
            Butterfly *butterfly = new Butterfly();
            scene->addItem(butterfly);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=4&&enemyNum<8){
            Spider *spider = new Spider();
            scene->addItem(spider);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=8&&enemyNum<12){
            elf *_elf = new elf();
            scene->addItem(_elf);
            enemyNum++;currentEnemyNum++;
            if(enemyNum==9){
                enemyNum=0;
                waves++;
                nextwave=0;
            }
        }
    }
    if(waves==6&&currentEnemyNum==0) nextwave=1;
    if(waves==6&&nextwave){
        if(enemyNum<5){
            Butterfly *butterfly = new Butterfly();
            scene->addItem(butterfly);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=5&&enemyNum<10){
            Spider *spider = new Spider();
            scene->addItem(spider);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=10&&enemyNum<15){
            elf *_elf = new elf();
            scene->addItem(_elf);
            enemyNum++;currentEnemyNum++;
            if(enemyNum==15){
                enemyNum=0;
                waves++;
                nextwave=0;
            }
        }
    }
    if(waves==7&&currentEnemyNum==0) nextwave=1;
    if(waves==7&&nextwave){
        if(enemyNum<2){
            Butterfly *butterfly = new Butterfly();
            scene->addItem(butterfly);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=2&&enemyNum<4){
            Spider *spider = new Spider();
            scene->addItem(spider);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=4&&enemyNum<7){
            elf *_elf = new elf();
            scene->addItem(_elf);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum==7){
            Lily *lily=new Lily();
            scene->addItem(lily);
            enemyNum++;currentEnemyNum++;
            enemyNum=0;
            waves++;
            nextwave=0;
        }
    }
    if(waves==8&&currentEnemyNum==0) nextwave=1;
    if(waves==8&&nextwave){
        if(enemyNum<3){
            Butterfly *butterfly = new Butterfly();
            scene->addItem(butterfly);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=3&&enemyNum<6){
            Spider *spider = new Spider();
            scene->addItem(spider);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=6&&enemyNum<10){
            elf *_elf = new elf();
            scene->addItem(_elf);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum==10){
            Lily *lily=new Lily();
            scene->addItem(lily);
            enemyNum++;currentEnemyNum++;
            enemyNum=0;
            waves++;
            nextwave=0;
        }
    }
    if(waves==9&&currentEnemyNum==0) nextwave=1;
    if(waves==9&&nextwave){
        if(enemyNum<4){
            Butterfly *butterfly = new Butterfly();
            scene->addItem(butterfly);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=4&&enemyNum<8){
            Spider *spider = new Spider();
            scene->addItem(spider);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=8&&enemyNum<13){
            elf *_elf = new elf();
            scene->addItem(_elf);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum==13){
            Lily *lily=new Lily();
            scene->addItem(lily);
            enemyNum++;currentEnemyNum++;
            enemyNum=0;
            waves++;
            nextwave=0;
        }
    }
    if(waves==10&&currentEnemyNum==0) nextwave=1;
    if(waves==10&&nextwave){
        if(enemyNum<4){
            elf *_elf = new elf();
            scene->addItem(_elf);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=4&&enemyNum<7){
            Lily *lily = new Lily();
            scene->addItem(lily);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum==7){
            Xiaoyue *xiaoyue=new Xiaoyue();
            scene->addItem(xiaoyue);
            waves++;
            currentEnemyNum++;
        }
    }

    if(waves==11&&currentEnemyNum==0&&playerHp>0){
        player2->stop();

        delete this;

        player3->setMedia(QUrl::fromLocalFile("C:/Cigarette/MyTowerDefense/music/Game3333.mp3"));
        player3->setVolume(30);
        player3->play();

        game = new Game3();
        game->show();

        return;
    }
}

void Game2::drawBackground(QPainter *painter, const QRectF &rect){
    QPixmap pixmap(":/scene/images/scene/background2.bmp");
    painter->drawPixmap(rect,pixmap,QRect());
    draw_Background(painter);
}



void Game2::setTowerPosition(){
    QPoint pos[] =
    {
        QPoint(360,117),
        QPoint(300,115),
        QPoint(240,122),

        QPoint(185,140),
        QPoint(150,180),
        QPoint(150, 230),

        QPoint(172,277),
        QPoint(270, 360),
        QPoint(330,370),
        QPoint(390, 370),
        QPoint(450, 365),
        QPoint(500,345),
        QPoint(520,305),
        QPoint(510,255),
        QPoint(480,205)
    };

    int len	= sizeof(pos) / sizeof(pos[0]);


    for(int i = 0;i<len; i++){
        pos[i] *= 2.1;
    }

    for (int i = 0; i < len; ++i){
        TowerPositionsList.push_back(new TowerPosition());
        TowerPositionsList[i]->setPos(pos[i]);
        TowerPositionsList[i]->setPixmap(QPixmap(":/tower/images/tower/imagek2.png"));
        scene->addItem(TowerPositionsList[i]);
    }



}


void Game2::draw_Background(QPainter * painter){
    QPixmap m_extensive(":/scene/images/scene/extensive.jpg");
    painter->drawPixmap(1400, 0, 484, 1200 ,m_extensive);    //右边扩展部分的总背景板

    QPixmap m_heroes(":/scene/images/scene/heroes2.png");
    painter->drawPixmap(1400, 0, 484, 423, m_heroes);    //塔类选择栏

    QPixmap m_waves(":/scene/images/scene/stage.png");
    painter->drawPixmap(1400, 423, 484, 147, m_waves);    //关卡数目

    QPixmap m_hp(":/scene/images/scene/waves.png");
    painter->drawPixmap(1400, 570, 484, 147, m_hp);    //敌人的波数

    QPixmap m_gold(":/scene/images/scene/gold.png");
    painter->drawPixmap(1400, 717, 484, 147, m_gold);    //金币数量

    QPixmap m_heart(":/scene/images/scene/heart.png");
    painter->drawPixmap(1590, 925, 207, 178, m_heart);    //七彩之心

    painter->setPen(QPen(Qt::red));
    painter->drawText(QRect(1600, 493, 1200, 500), QString("HP : %1").arg(playerHp));    //关卡数目

    painter->setPen(QPen(Qt::red));
    painter->drawText(QRect(1590, 643, 1200, 500), QString("WAVE : %1").arg(waves));    //敌人波数

    painter->setPen(QPen(Qt::red));
    painter->drawText(QRect(1590, 793, 100, 500), QString("GOLD : %1").arg(gold));    //金币数目

    BuildTowerIcon * aic = new ArrowTowerBuildIcon();
    scene->addItem(aic);

    BuildTowerIcon * cic = new CannonTowerBuildIcon();
    scene->addItem(cic);

    BuildTowerIcon * sic = new  SlowTowerBuildIcon();
    scene->addItem(sic);

    BuildTowerIcon * gic = new GreenTowerBuildIcon();
    scene->addItem(gic);

}


