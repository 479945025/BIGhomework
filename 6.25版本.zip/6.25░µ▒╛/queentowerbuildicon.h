#ifndef QUEENTOWERBUILDICON_H
#define QUEENTOWERBUILDICON_H
#include"buildtowericon.h"
#include"queenbullet.h"
#include"queentower.h"

class QueenTowerBuildIcon:public BuildTowerIcon
{
public:
    QueenTowerBuildIcon(QGraphicsItem * parent=0);
    virtual void mousePressEvent(QGraphicsSceneMouseEvent *event);
};

#endif // QUEENTOWERBUILDICON_H
