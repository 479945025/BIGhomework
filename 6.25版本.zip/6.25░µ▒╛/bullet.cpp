#include "bullet.h"
#include <QPixmap>
#include <QTimer>
#include "game.h"
#include <QPropertyAnimation>
#include"tower.h"

extern Game * game;

Bullet::Bullet(QGraphicsItem * parent): QObject(),QGraphicsPixmapItem(parent){}

void Bullet::move(){
    static const int duration = 200;
    QPropertyAnimation *animation = new QPropertyAnimation(this, "b_currentPos");
    animation->setDuration(duration);
    animation->setStartValue(startPos);
    animation->setEndValue(targetPos);
    connect(animation, SIGNAL(finished()), this, SLOT(hitTarget()));
    animation->start();
}

void Bullet::hitTarget(){
    if(target->active == 1){
        target->getDamage(damage);
        target->draw();
    }
    game->scene->removeItem(this);
    delete this;
}

void Bullet::setCurrentPos(QPointF pos){
    b_currentPos = pos;
    setPos(b_currentPos);
}

QPointF Bullet::currentPos() const{
    return b_currentPos;
}
