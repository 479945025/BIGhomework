#ifndef CANNONTOWERBUILDICON_H
#define CANNONTOWERBUILDICON_H
#include"buildtowericon.h"
#include"cannonbullet.h"
#include"cannontower.h"

class CannonTowerBuildIcon: public BuildTowerIcon
{
public:
    CannonTowerBuildIcon(QGraphicsItem * parent=0);
    virtual void mousePressEvent(QGraphicsSceneMouseEvent *event);
};

#endif // CANNONTOWERBUILDICON_H
