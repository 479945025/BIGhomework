#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "game.h"
#include"game1.h"
#include"game2.h"
#include"game3.h"
#include<QPushButton>
#include<QHBoxLayout>
#include<QPainter>
#include<QtMultimedia/QMediaPlayer>
//JIARU

#include<QMovie>
#include<QLabel>
#include<QtMultimedia/QMediaPlayer>

extern Game * game;
extern QMediaPlayer * player;

QMediaPlayer * player1 = new QMediaPlayer;
QMediaPlayer * player2 = new QMediaPlayer;
QMediaPlayer * player3 = new QMediaPlayer;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{

    ui->setupUi(this);
   // receivestory();

}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::paintEvent(QPaintEvent *)
{

    QPixmap background(":/scene/images/scene/scene.jpg");
    QPainter painter(this);
    painter.drawPixmap(0,0,background);
    player->setMedia(QUrl("qrc:/music/music/Game2.mp3"));
    player->setVolume(30);
    player->play();

}

void MainWindow::receivechoose()
{
    this->show();


}

void MainWindow::on_pushButton_clicked()
{
    this->hide();
    game = new Game1();
    game -> show();
    player->stop();

    //connect(player1, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));



  //  player1->setMedia(QUrl::fromLocalFile("C:/Cigarette/MyTowerDefense/music/Game1.mp3"));
     player1->setMedia(QUrl("qrc:/music/music/Game1.mp3"));
    player1->setVolume(30);
    player1->play();
}

void MainWindow::on_pushButton_2_clicked()
{
    this->hide();
    emit startshow();
}

void MainWindow::on_pushButton_3_clicked(){
    this->hide();
    game = new Game2();
    game->show();
    player->stop();
    //connect(player2, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player2->setMedia(QUrl("qrc:/music/music/Game2.mp3"));
    player2->setVolume(30);
    player2->play();
}

void MainWindow::on_pushButton_4_clicked(){
    this->hide();
    game = new Game3();
    game->show();
    player->stop();
    //connect(player3, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player3->setMedia(QUrl("qrc:/music/music/Game3.mp3"));
    player3->setVolume(30);
    player3->play();
}
//尝试
void MainWindow::receivestory()
{
    this->show();
     label->close();
    QMovie * movie = new QMovie(":/scene/images/scene/scene_g.gif");
    movie->setSpeed(100);
        label = new QLabel;
        label->setMovie(movie);
        movie->start();
        label->show();


}
