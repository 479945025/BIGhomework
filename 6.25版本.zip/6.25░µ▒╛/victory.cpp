#include "victory.h"
#include "ui_victory.h"
#include <QPainter>
victory::victory(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::victory)
{
    ui->setupUi(this);
}

victory::~victory()
{
    delete ui;
}

void victory::paintEvent(QPaintEvent *)
{
    QPixmap background(":/scene/images/scene/success.jpg");
    QPainter painter(this);
    painter.drawPixmap(0,0,background);
}
void victory::on_pushButton_clicked()
{
    this->hide();
    emit  showmainwindow();
}
void victory::receivevictory()
{
    this->show();
}
