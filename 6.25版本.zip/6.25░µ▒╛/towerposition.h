#ifndef TOWERPOSITION_H
#define TOWERPOSITION_H

#include <QGraphicsPixmapItem>
#include <QGraphicsPolygonItem>
#include <QGraphicsItem>
#include <QPointF>
#include <QObject>
#include <QSize>
#include <QPixmap>

class TowerPosition:public QObject,public QGraphicsPixmapItem{
    Q_OBJECT
public:
    TowerPosition(QGraphicsItem * parent=0);
    const QPointF centerPos() const;

    bool Point_Place (const QPointF & pos) const;
    void setTower_Exist(bool _Tower_Exist = true);
    bool testTower_Exist();


private:
    bool Tower_Exist;

    static const QSize fixedSize;
};

#endif // TOWERPOSITION_H
