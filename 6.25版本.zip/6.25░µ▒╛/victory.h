#ifndef VICTORY_H
#define VICTORY_H

#include <QWidget>

namespace Ui {
class victory;
}

class victory : public QWidget
{
    Q_OBJECT

public:
    explicit victory(QWidget *parent = nullptr);
    ~victory();
    void paintEvent(QPaintEvent *);

private slots:
    void on_pushButton_clicked();
    void receivevictory();
signals:
    void showmainwindow();

private:
    Ui::victory *ui;
};

#endif // VICTORY_H
