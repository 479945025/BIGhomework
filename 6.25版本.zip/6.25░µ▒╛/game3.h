#ifndef GAME3_H
#define GAME3_H

#include <QTime>
#include <QGraphicsView>
#include <QMouseEvent>
#include <QGraphicsPixmapItem>
#include "towerposition.h"
#include <QList>
#include "tower.h"
#include "enemy.h"
#include"buildtowericon.h"
#include"arrowtowerbuildicon.h"
#include"cannontowerbuildicon.h"
#include"deletebutton.h"
#include"upgradebutton.h"
#include<QObject>
#include"greentowerbuildicon.h"
#include"slowtowerbuildicon.h"
#include"queentowerbuildicon.h"
#include"butterfly.h"
#include"game.h"
#include"victory.h"

class Game3:public Game{

public:
    Game3();
    void setTowerPosition();
    void draw_Background(QPainter * painter);
    victory * Victory;
public slots:
    void drawEnemy();
protected:
    void drawBackground(QPainter *painter, const QRectF &rect);

};
#endif // GAME3_H
