#ifndef UPGRADEBUTTON_H
#define UPGRADEBUTTON_H
#include <QGraphicsPixmapItem>
#include <QGraphicsSceneMouseEvent>
#include"tower.h"


class UpgradeButton:public QGraphicsPixmapItem
{
public:
    UpgradeButton(QGraphicsItem * parent=0);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    Tower * tower;
};

#endif // UPGRADEBUTTON_H
