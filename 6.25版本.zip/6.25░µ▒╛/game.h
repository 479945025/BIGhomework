#ifndef GAME_H
#define GAME_H

#include <QTime>
#include <QGraphicsView>
#include <QMouseEvent>
#include <QGraphicsPixmapItem>
#include "towerposition.h"
#include <QList>
#include "tower.h"
#include "enemy.h"
#include"buildtowericon.h"
#include"arrowtowerbuildicon.h"
#include"cannontowerbuildicon.h"
#include"deletebutton.h"
#include"upgradebutton.h"
#include<QObject>
#include"greentowerbuildicon.h"
#include"slowtowerbuildicon.h"
#include"queentowerbuildicon.h"
#include"butterfly.h"
#include"spider.h"
#include"elf.h"
#include"lily.h"
#include"gunala.h"
#include"xiaoyue.h"
#include"butterfly.h"

class Game: public QGraphicsView{
    Q_OBJECT
public:
    Game();
    virtual void setTowerPosition()=0;
    QGraphicsScene * scene;

    void setCursor(QString filename);
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    virtual void draw_Background(QPainter * painter)=0;

    void removeBullet(Bullet * bullet);
    void addEnemy(Butterfly * butterfly);
    QGraphicsPixmapItem * cursor;
    Tower * build;
    DeleteButton * deletebutton;
    UpgradeButton * upgradebutton;
    QList<TowerPosition*> TowerPositionsList;

    int waves=1;
    int playerHp;
    int gold;
    int enemyNum=0;
    int currentEnemyNum=0;
    bool nextwave=1;
    int level=1;
    QList<QPoint> points_1;
    QList<QPoint> points_2;

private slots:
    virtual void drawEnemy()=0;

private:

    //需要虚函数才可以实现重载

protected:
    virtual void drawBackground(QPainter *painter, const QRectF &rect)=0;

};

#endif // GAME_H
