#include "Tower.h"
#include <QPixmap>
#include <QVector>
#include <QPointF>
#include <QPolygonF>
#include <QPointF>
#include <QLineF>
#include "game.h"
#include <QTimer>
#include <QGraphicsRectItem>
#include <QDebug>
#include <QVector2D>
#include <QtMath>
#include"deletebutton.h"
#include"upgradebutton.h"
#include"QDebug"
#include"blacktower.h"
#include<QtMultimedia/QMediaPlayer>

extern Game * game;

Tower::Tower(QGraphicsItem * parent):QObject(),QGraphicsPixmapItem (parent){
    setZValue(1);
    chooseEnemy = NULL;
    grade = 1;
    black = 0;
}

void Tower::check_EnemyInRange(){
     double closest_dist = attackRange;
     has_target = false;
     closest_pt = QPointF(0,0);

     QList<QGraphicsItem*> colliding_items = attack_area->collidingItems();
     for(size_t i = 0,n = colliding_items.size(); i < n; i++){
         Enemy * enemy = dynamic_cast<Enemy *>(colliding_items[i]);
         if(enemy){
             double this_dist = distanceto(colliding_items[i]);
             if(this_dist < closest_dist){
                 closest_dist = this_dist;
                 closest_pt = colliding_items[i]->pos() + QPointF(0,0);
                 chooseEnemy = enemy;
                 has_target = true;
             }
         }
     }

     if(has_target){
         attack_desk = closest_pt;
         chooseEnemy->getAttacked(this);
         attack_Enemy();
     }
     else{
         lostSightOfEnemy();
     }
}

double Tower::distanceto(QGraphicsItem *item){
    QLineF ln(QPointF(x(),y()),item->pos());
    return ln.length();
}

Tower::~Tower(){


}

void Tower::target_Killed(){
    if(chooseEnemy){
        chooseEnemy = NULL;
    }
}

void Tower::lostSightOfEnemy(){
    if(chooseEnemy){
        chooseEnemy->gotLostSight(this);
        chooseEnemy = NULL;
    }
}

void Tower::mousePressEvent(QGraphicsSceneMouseEvent *event){
    if(game->deletebutton){
        game->scene->removeItem(game->deletebutton);
        game->deletebutton = nullptr;

        game->scene->removeItem(game->upgradebutton);
        game->upgradebutton = nullptr;
    }
    else{
        game->deletebutton = new DeleteButton();
        game->deletebutton->setPos(QPointF(x()+60,y()-55));
        game->deletebutton->tower = this;
        game->scene->addItem(game->deletebutton);

        if(game->gold - money < 0 || grade >= 3){
            game->upgradebutton = new UpgradeButton();
            game->upgradebutton->setPos(QPointF(x()-55,y()-60));
            game->upgradebutton->tower = this;
            game->upgradebutton->setPixmap(QPixmap(":/scene/images/scene/updategrey.png"));
            game->scene->addItem(game->upgradebutton);
        }
        else{
            game->upgradebutton = new UpgradeButton();
            game->upgradebutton->setPos(QPointF(x()-55,y()-60));
            game->upgradebutton->tower = this;
            game->scene->addItem(game->upgradebutton);
        }

    }

}

void Tower::getTowerPosition(TowerPosition * _towerposition){
    towerposition = _towerposition;
}


int Tower::getmoney(){
    return money;
}

bool Tower::testblack(){
    return black;
}
