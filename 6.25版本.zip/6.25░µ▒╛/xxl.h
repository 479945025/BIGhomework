#ifndef XXL_H
#define XXL_H

#include <QWidget>

namespace Ui {
class xxl;
}

class xxl : public QWidget
{
    Q_OBJECT

public:
    explicit xxl(QWidget *parent = nullptr);
    ~xxl();
    void paintEvent(QPaintEvent *);


private slots:
    void on_pushButton_clicked();
    void receivexxl();
signals:
    void playshow();
private:
    Ui::xxl *ui;
};

#endif // XXL_H
