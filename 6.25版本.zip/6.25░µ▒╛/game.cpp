#include"game.h"
#include<QGraphicsScene>
#include<qdebug.h>
#include"xiaoyue.h"
#include"victory.h"



Game::Game():QGraphicsView (){


}

void Game::setCursor(QString filename){
    if (cursor){
        scene->removeItem(cursor);
        delete cursor;
    }

    cursor = new QGraphicsPixmapItem();
    cursor->setPixmap(QPixmap(filename));
    scene->addItem(cursor);
}

void Game::mouseMoveEvent(QMouseEvent *event){
    if (cursor){
        cursor->setPos(event->pos());
    }

}

void Game::mousePressEvent(QMouseEvent *event){
    if(build){
       if(event->button() == Qt::LeftButton){
           QPoint pressPos = event->pos();
           for(int i=0; i<TowerPositionsList.size(); i++){
               if(!TowerPositionsList[i]->testTower_Exist() && TowerPositionsList[i]->Point_Place(pressPos)){
                   TowerPositionsList[i]->setTower_Exist();
                   build->getTowerPosition(TowerPositionsList[i]);

                   scene->addItem(build);

                   build->setPos(TowerPositionsList[i]->centerPos()+QPointF(0,-build->pixmap().height()*0.5));

                   delete cursor;
                   cursor = nullptr;
                   build = nullptr;
                   break;
               }
           }
       }
       else if(event->button() == Qt::RightButton){
           gold += build->getmoney();
           delete cursor;
           build = nullptr;
           cursor = nullptr;
       }

    }
    else{
         QGraphicsView::mousePressEvent(event);
    }


}



void Game::addEnemy(Butterfly *butterfly){
    currentEnemyNum++;
    scene->addItem(butterfly);
}
