#ifndef CANNONTOWER_H
#define CANNONTOWER_H
#include"tower.h"
#include"buildtowericon.h"

class CannonTower:public Tower
{
public:
    CannonTower(QGraphicsItem * parent = 0);
    virtual void attack_Enemy();
    virtual void upgrade();
    virtual void getblack();
};

#endif // CANNONTOWER_H
