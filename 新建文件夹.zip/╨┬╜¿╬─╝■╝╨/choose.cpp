#include "choose.h"
#include "ui_choose.h"

choose::choose(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::choose)
{
    ui->setupUi(this);
}

choose::~choose()
{
    delete ui;
}

void choose::on_pushButton_clicked()
{
    this
}
