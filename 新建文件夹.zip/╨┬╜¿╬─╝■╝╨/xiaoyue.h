#ifndef XIAOYUE_H
#define XIAOYUE_H

#include<enemy.h>
#include <QGraphicsPixmapItem>
#include <QObject>
class Xiaoyue:public Enemy
{
public:
    Xiaoyue(QGraphicsItem *parent=nullptr);
};

#endif // XIAOYUE_H
