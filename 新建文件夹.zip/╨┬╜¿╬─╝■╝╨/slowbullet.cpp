#include "slowbullet.h"
#include"game.h"
#include"qdebug.h"

extern Game * game;

SlowBullet::SlowBullet(QGraphicsItem * parent):Bullet (parent)
{

}

void SlowBullet::setInfo(QPointF _targetPos, int _damage, Enemy *_target){
    setPixmap(QPixmap(":/bullet/images/bullet/mxzd_20x20.png"));
    startPos = pos();
    targetPos = _targetPos;
    b_currentPos = startPos;
    damage = _damage;
    target = _target;
}

void SlowBullet::hitTarget(){
    if(target->active == 1){
        target->getDamage(damage);
        target->getslow(slow_rate);
        target->draw();
    }

    game->scene->removeItem(this);
    delete this;
}

void SlowBullet::setslow_rate(int _slow_rate){
    slow_rate = _slow_rate;
}
