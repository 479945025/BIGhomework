#ifndef ENEMY_H
#define ENEMY_H
#include<mainwindow.h>
#include <QGraphicsPixmapItem>
#include <QObject>
#include <QList> // list << element
#include <QPointF>
#include"failure.h"
#include<math.h>
class Tower;

class Enemy: public QObject, public QGraphicsPixmapItem{
    Q_OBJECT
public:
    Enemy(QGraphicsItem * parent=nullptr);
    Enemy(QList<QPoint> points);
    ~Enemy();
    void setPoints();
    void getDamage(int damage);
    virtual void getRemoved();
    void setmaxHp(int m);
    void setwalkingSpeed(int w);
    void setdefend(int d);
    QList<QPoint> getpoints(){
        return points;
    }
    void getAttacked(Tower *attacker);
    void gotLostSight(Tower *attacker);
    void draw();
    void getslow(int s);
    void getweak(int w);
        int currentHp;
    //bool active=0;
    int point_index;
    QPoint dest;
    QPoint _dest;
    int getmaxHp(){
        return maxHp;
    }
    inline bool collisionWithCircle(QPointF point1,QPoint &point2){
        if (sqrt((point1.x()-point2.x())*(point1.x()-point2.x())+(point1.y()-point2.y())*(point1.y()-point2.y()))<1)
            return true;
        else
            return false;
    }
    void setcurrentHp(int c){
        currentHp=c;
    }
    bool active=1;

public slots:
    void resetslow();
    void resetweak();
    void move_forward();
    void butterflyProduce();
signals:
    void showfailure();
protected:
    int weak=0;
    int defense;
    int slow=0;
    int maxHp;

    int walkingSpeed;
    //QList<Enemy *> enemyList;
    QList<QPoint> points;

    static const QSize fixedSize;
    QGraphicsRectItem * hp;
    QGraphicsRectItem * tmp_hp;

    failure * Failure;
    QTimer * timer;
    QTimer * slowtimer;
    QTimer * weaktimer;

    QList<Tower *>	attackedTowersList;
};

#endif // ENEMY_H
