#include "xnw.h"
#include "ui_xnw.h"
#include<QPainter>
xnw::xnw(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::xnw)
{
    ui->setupUi(this);
}

xnw::~xnw()
{
    delete ui;
}
void xnw::paintEvent(QPaintEvent *)
{
    QPixmap background(":/scene/images/scene/mxnw.jpg");
    QPainter painter(this);
    painter.drawPixmap(0,0,background);
}
void xnw::on_pushButton_clicked()
{
    this->hide();
    emit  playshow();
}
void xnw::receivexnw()
{
    this->show();
}
