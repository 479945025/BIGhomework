#include "cannonbullet.h"
#include "game.h"
#include <QPropertyAnimation>
#include"tower.h"
#include<QDebug>

extern Game * game;

CannonBullet::CannonBullet(QGraphicsItem * parent):Bullet (parent)
{
    bullet_area = new QGraphicsEllipseItem(0,0,150,150,this);
    bullet_area->setPos(QPointF(-45,-45));

    QPen pen = QPen(Qt::DotLine);
    pen.setColor(Qt::yellow);
    pen.setWidth(1);
    bullet_area->setPen(pen);

}

void CannonBullet::setInfo(QPointF _targetPos, int _damage, Enemy *_target){
    setPixmap(QPixmap(":/bullet/images/bullet/xlzd_60x60.png"));
    startPos = pos();
    targetPos = _targetPos;
    b_currentPos = startPos;
    damage = _damage;
    target = _target;
}

void CannonBullet::hitTarget(){
    if(target->active == 1){
        target->getDamage(damage);
        target->draw();
    }


    QList<QGraphicsItem*> colliding_items = bullet_area->collidingItems();

    for(size_t i = 0,n = colliding_items.size(); i < n; i++){
        Enemy * enemy = dynamic_cast<Enemy *>(colliding_items[i]);
        if(enemy){
                enemy->getDamage(damage);
                enemy->draw();
            }
     }

    game->scene->removeItem(this);

    delete this;
}

