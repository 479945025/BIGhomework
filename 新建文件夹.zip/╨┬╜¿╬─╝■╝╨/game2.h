#ifndef GAME2_H
#define GAME2_H
#include"game.h"
#include <QTime>
#include <QGraphicsView>
#include <QMouseEvent>
#include <QGraphicsPixmapItem>
#include "towerposition.h"
#include <QList>
#include "tower.h"
#include "enemy.h"
#include"buildtowericon.h"
#include"arrowtowerbuildicon.h"
#include"cannontowerbuildicon.h"
#include"deletebutton.h"
#include"upgradebutton.h"
#include<QObject>
#include"greentowerbuildicon.h"
#include"slowtowerbuildicon.h"
#include"queentowerbuildicon.h"
#include"butterfly.h"

class Game2:public Game{

public:
    Game2();
    void setTowerPosition();
    void draw_Background(QPainter * painter);
public slots:
    void drawEnemy();
protected:
    void drawBackground(QPainter *painter, const QRectF &rect);

};

#endif // GAME2_H
