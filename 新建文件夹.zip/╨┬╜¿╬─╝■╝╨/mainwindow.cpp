#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "game.h"
#include"game1.h"
#include"game2.h"
#include"game3.h"
#include<QPushButton>
#include<QHBoxLayout>
#include<QPainter>
#include<QtMultimedia/QMediaPlayer>

extern Game * game;
extern QMediaPlayer * player;

QMediaPlayer * player1 = new QMediaPlayer;
QMediaPlayer * player2 = new QMediaPlayer;
QMediaPlayer * player3 = new QMediaPlayer;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::paintEvent(QPaintEvent *)
{
    QPixmap background(":/scene/images/scene/scene.jpg");
    QPainter painter(this);
    painter.drawPixmap(0,0,background);
}

void MainWindow::receivechoose()
{
    this->show();
}

void MainWindow::on_pushButton_clicked()
{
    this->hide();
    game = new Game1();
    game -> show();
    player->stop();
    player1->play();
}

void MainWindow::on_pushButton_2_clicked()
{
    this->hide();
    emit startshow();
}

void MainWindow::on_pushButton_3_clicked(){
    this->hide();
    game = new Game2();
    game->show();
    player->stop();
    player2->play();
}

void MainWindow::on_pushButton_4_clicked(){
    this->hide();
    game = new Game3();
    game->show();
    player->stop();
    player3->play();
}
