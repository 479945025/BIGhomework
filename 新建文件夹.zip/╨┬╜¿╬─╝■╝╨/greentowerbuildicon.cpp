#include "greentowerbuildicon.h"
#include"game.h"

extern Game * game;

GreenTowerBuildIcon::GreenTowerBuildIcon(QGraphicsItem * parent) : BuildTowerIcon(parent)
{
    setPixmap(QPixmap(":/scene/images/scene/1423-253.png"));
    this->setPos(1423,253);
}

void GreenTowerBuildIcon::mousePressEvent(QGraphicsSceneMouseEvent *event){
    if (!game->build && (game->gold - 200) >= 0){
        game->build = new GreenTower();
        game->setCursor(QString(":/tower/images/tower/lmxtm_44x66.png"));
    }
}
