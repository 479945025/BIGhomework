#include "queenbullet.h"
#include "bullet.h"
#include <QPixmap>
#include <QTimer>
#include <qmath.h> // qSin, qCos, qTan
#include "game.h"
#include <QPropertyAnimation>
#include"tower.h"

QueenBullet::QueenBullet(QGraphicsItem * parent):QObject (),QGraphicsPixmapItem (parent)
{
    count = 0;
    setZValue(0);
    timer = new QTimer(this);
    changecondition = false;
    connect(timer,SIGNAL(timeout()),this,SLOT(changepictures()));
}

void QueenBullet::changepictures(){
      setTransformOriginPoint(255,255);
      setRotation(10*count);
      count++;
      this->setPixmap(QPixmap(":/bullet/images/bullet/mofazheng_500x500.png"));

}

void QueenBullet::startchange(){
    timer->start(50);
    changecondition = true;
}

void QueenBullet::stopchange(){
    timer->stop();
    setPixmap(QPixmap());
    changecondition = false;
}
