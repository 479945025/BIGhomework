#include "upgradebutton.h"
#include"game.h"

extern Game * game;

UpgradeButton::UpgradeButton(QGraphicsItem *parent): QGraphicsPixmapItem(parent){
    setPixmap(QPixmap(":/scene/images/scene/upgrade_100x70.png"));
}

void UpgradeButton::mousePressEvent(QGraphicsSceneMouseEvent *event){
    tower->upgrade();
    game->scene->removeItem(game->deletebutton);
    game->scene->removeItem(this);

    game->upgradebutton = nullptr;
    game->deletebutton = nullptr;
}
