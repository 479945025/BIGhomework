#ifndef DELETEBUTTON_H
#define DELETEBUTTON_H

#include <QGraphicsPixmapItem>
#include <QGraphicsSceneMouseEvent>
#include"tower.h"

class DeleteButton:public QGraphicsPixmapItem
{
public:
    DeleteButton(QGraphicsItem * parent=0);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    Tower * tower;
};

#endif // DELETEBUTTON_H
