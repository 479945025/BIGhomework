#ifndef BLACKTOWER_H
#define BLACKTOWER_H
#include"tower.h"

class BlackTower:public Tower
{
public:
    BlackTower(QGraphicsItem * parent = 0);
    virtual void attack_Enemy();
    virtual void upgrade();
    virtual void mousePressEvent(QGraphicsSceneMouseEvent *event);
    virtual void getblack();
};

#endif // BLACKTOWER_H
