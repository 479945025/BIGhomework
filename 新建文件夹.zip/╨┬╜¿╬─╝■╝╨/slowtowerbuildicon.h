#ifndef SLOWTOWERBUILDICON_H
#define SLOWTOWERBUILDICON_H
#include"buildtowericon.h"
#include"slowbullet.h"
#include"slowtower.h"

class SlowTowerBuildIcon:public BuildTowerIcon
{
public:
    SlowTowerBuildIcon(QGraphicsItem * parent=0);
    virtual void mousePressEvent(QGraphicsSceneMouseEvent *event);
};

#endif // SLOWTOWERBUILDICON_H
