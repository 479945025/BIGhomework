#ifndef SLOWBULLET_H
#define SLOWBULLET_H
#include"bullet.h"

class SlowBullet:public Bullet
{
public:
    SlowBullet(QGraphicsItem * parent = 0);
    virtual void setInfo(QPointF _targetPos, int _damage, Enemy *_target);
    virtual void hitTarget();
    void setslow_rate(int _slow_rate);
private:
    int slow_rate;
};

#endif // SLOWBULLET_H
