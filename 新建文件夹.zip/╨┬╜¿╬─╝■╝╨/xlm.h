#ifndef XLM_H
#define XLM_H

#include <QWidget>

namespace Ui {
class xlm;
}

class xlm : public QWidget
{
    Q_OBJECT

public:
    explicit xlm(QWidget *parent = nullptr);
    ~xlm();
    void paintEvent(QPaintEvent *);


private slots:
    void on_pushButton_clicked();
    void receivexlm();
signals:
    void playshow();
private:
    Ui::xlm *ui;
};

#endif // XLM_H
