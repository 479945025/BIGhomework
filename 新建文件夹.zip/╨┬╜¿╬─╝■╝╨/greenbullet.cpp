#include "greenbullet.h"


GreenBullet::GreenBullet(QGraphicsItem * parent):Bullet (parent)
{

}

void GreenBullet::setInfo(QPointF _targetPos, int _damage, Enemy *_target){
    setPixmap(QPixmap(":/bullet/images/bullet/lmxzd_25x25.png"));
    startPos = pos();
    targetPos = _targetPos;
    b_currentPos = startPos;
    damage = _damage;
    target = _target;
}
