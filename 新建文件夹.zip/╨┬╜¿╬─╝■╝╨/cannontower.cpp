#include "cannontower.h"
#include"game.h"
#include"cannonbullet.h"
#include"blacktower.h"

extern Game * game;

CannonTower::CannonTower(QGraphicsItem * parent):Tower (parent)
{
    setPixmap(QPixmap(":/tower/images/tower/xlLv.1_44x66.png"));
    attacking = false;
    attackRange = 250;
    damage = 60;

    money = 200;
    game->gold -= money;
    center_pos = QPointF(this->pixmap().width()*0.5,this->pixmap().height()*0.5);
    attack_desk = QPointF(0,0);
    has_target = false;

    attack_desk = QPointF(0,0);
    has_target = false;

    //1秒发一次子弹
    QTimer * timer = new QTimer();
    connect(timer,SIGNAL(timeout()),this,SLOT(check_EnemyInRange()));
    timer->start(1000);

    //画攻击范围
    attack_area = new QGraphicsEllipseItem(0,0,attackRange*2,attackRange*2,this);
    QPen pen = QPen(Qt::DotLine);
    pen.setColor(Qt::lightGray);
    pen.setWidth(0);
    attack_area->setPen(pen);

    //画攻击范围
    QPointF offsetPoint(this->pixmap().width()*0.5,this->pixmap().height()*0.5);

    attack_area->setPos(offsetPoint + QPointF(-attackRange,-attackRange));

}

void CannonTower::attack_Enemy(){
    Bullet * bullet = new CannonBullet ();
    game->scene->addItem(bullet);

    bullet->setPos(x()+40,y()+40);
    bullet->setInfo(attack_desk,damage,chooseEnemy);

    QLineF ln(QPointF(x()+40,y()+40),attack_desk);
    int angle = -1 * ln.angle();
    bullet->setRotation(angle);

    bullet->move();

}

void CannonTower::upgrade(){
    if(grade >= 3)
        return;

    if((game->gold - 100 * (grade+1)) >= 0){
        grade++;
        if(grade ==2){
            setPixmap(QPixmap(":/tower/images/tower/xlLv.2_66x88.png"));
            setPos(QPointF(x()-20,y()));
            center_pos = QPointF(this->pixmap().width()*0.5,this->pixmap().height()*0.5);
        }
        else if(grade == 3){
            setPixmap(QPixmap(":/tower/images/tower/xlLv.3_110x136.png"));
            setPos(QPointF(x()-25,y()));
            center_pos = QPointF(this->pixmap().width()*0.5,this->pixmap().height()*0.5);
        }

        attackRange += 50;
        damage += 50;
        game->gold -= 200;

        game->scene->removeItem(attack_area);
        attack_area = nullptr;
        attack_area = new QGraphicsEllipseItem(0,0,attackRange*2,attackRange*2,this);

        QPen pen = QPen(Qt::DotLine);
        pen.setColor(Qt::lightGray);
        pen.setWidth(0);
        attack_area->setPen(pen);

        QPointF offsetPoint(this->pixmap().width()*0.5,this->pixmap().height()*0.5);
        attack_area->setPos(offsetPoint + QPointF(-attackRange,-attackRange));
    }
}

void CannonTower::getblack(){
    black = 1;

    BlackTower * blacktower = new BlackTower();
    blacktower->setPos(QPointF(x()-40,y()));
    blacktower->setPixmap(QPixmap(":/tower/images/tower/gxl_110x136.png"));

    game->scene->addItem(blacktower);
    game->scene->removeItem(this);
    delete this;
}
