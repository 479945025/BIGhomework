#include "slowtowerbuildicon.h"
#include"game.h"

extern Game * game;

SlowTowerBuildIcon::SlowTowerBuildIcon(QGraphicsItem * parent): BuildTowerIcon(parent)
{
    setPixmap(QPixmap(":/scene/images/scene/1575-90.png"));
    this->setPos(1575,90);
}

void SlowTowerBuildIcon::mousePressEvent(QGraphicsSceneMouseEvent *event){
    if (!game->build && (game->gold - 200) >= 0){
        game->build = new SlowTower();
        game->setCursor(QString(":/tower/images/tower/mxtm_44x66.png"));
    }
    else{
        //金钱不足
    }
}
