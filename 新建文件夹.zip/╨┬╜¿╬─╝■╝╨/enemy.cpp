#include "enemy.h"
#include <QPixmap>
#include <QTimer>
#include <qmath.h>
#include<QPainter>
#include <QDebug>
#include "game.h"
#include<QPen>
#include<QGraphicsView>
#include<QGraphicsScene>
#include<QWidget>
#include"failure.h"

extern Game * game;


const QSize Enemy::fixedSize(52, 52);
Enemy::Enemy(QGraphicsItem *parent){
    setZValue(1);
}

void Enemy::setmaxHp(int m){
    maxHp=m;
}

void Enemy::setwalkingSpeed(int w){
    walkingSpeed=w;
}

void Enemy::setdefend(int d){
    defense=d;
}

void Enemy::setPoints()
{
    if(game->waves%2==1)
        points = game->points_1;
    else {
        points = game->points_2;
    }
}

void Enemy::draw(){
    if(active==0) return;
    hp = nullptr;
    tmp_hp = nullptr;
    hp = new QGraphicsRectItem(10,0,40,2,this);
    QPen pen = QPen(Qt::SolidLine);
    hp->setBrush(Qt::green);
    tmp_hp=new QGraphicsRectItem(10,0,40*currentHp/maxHp,2,this);
    tmp_hp->setBrush(Qt::red);

}

void Enemy::resetslow(){
    slow=0;
}

void Enemy::resetweak(){
    weak=0;
}

void Enemy::move_forward(){
    // if close to dest, rotate to next dest
    /*QLineF ln(pos(),dest);
    if (ln.length() < 5){
        point_index++;
        // last point reached
        if (point_index >= points.size()){
            if(active==1){
                game->playerHp--;
                if(game->playerHp <= 0){
                    Failure = new failure();
                    Failure->show();

                    game->close();
                    delete game;
                    return;
                }
                getRemoved();

            }

            return;
        }

        dest = points[point_index];
        rotateToPoint(dest);
    }
    // move enemy forward at current angle
    double theta = rotation(); // degrees
    //double theta=qAtan((points[point_index+1].y()-dest.y())/(points[point_index+1].x()-dest.x()));
    double dy = (walkingSpeed-slow) * qSin(qDegreesToRadians(theta));
    double dx = (walkingSpeed-slow) * qCos(qDegreesToRadians(theta));
    setPos(x()+dx, y()+dy);*/
    if (collisionWithCircle(this->pos(), _dest)){
        pos()=_dest;
        point_index++;
        // 敌人抵达了一个航点
        if (point_index<points.size())	{
            // 还有下一个航点
            _dest=points[point_index];
        }
        else{
            // 表示进入基地
            game->playerHp--;
            getRemoved();
            if(game->playerHp <= 0){
                Failure = new failure();
                Failure->show();
                game->close();
                delete game;
                return;
            }
            return;
        }
    }
    //qDebug()<<dest<<" "<<_dest;
    QVector2D normalized(_dest-pos());
    normalized.normalize();
    setPos(this->pos()+normalized.toPoint()*(walkingSpeed-slow));
}

void Enemy::getDamage(int damage){
    int realdamage=damage+weak-defense;
    if(realdamage<=0) realdamage=0;

    currentHp=currentHp-realdamage;
    if(currentHp<=0){
        getRemoved();
    }
}

void Enemy::getweak(int w){
    weak=w;
    QTimer::singleShot(3000,this,SLOT(resetweak()));
}

void Enemy::getslow(int s){
    slow=s;
    QTimer::singleShot(3000,this,SLOT(resetslow()));
}

void Enemy::getRemoved(){
    foreach(Tower * attacker,attackedTowersList){
        attacker->target_Killed();
    }
    attackedTowersList.clear();
    active=0;

    game->currentEnemyNum--;

    game->scene->removeItem(this);

    delete this;
}

void Enemy::getAttacked(Tower *attacker)
{
    attackedTowersList.push_back(attacker);
}

void Enemy::gotLostSight(Tower *attacker)
{
    attackedTowersList.removeOne(attacker);
}

Enemy::~Enemy(){

}
