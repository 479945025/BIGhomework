#include "arrowbullet.h"
#include <QPropertyAnimation>

ArrowBullet::ArrowBullet(QGraphicsItem * parent):Bullet (parent)
{

}

void ArrowBullet::setInfo(QPointF _targetPos, int _damage, Enemy *_target){
    setPixmap(QPixmap(":/bullet/images/bullet/mqzd_20x20.png"));
    startPos = pos();
    targetPos = _targetPos;
    b_currentPos = startPos;
    damage = _damage;
    target = _target;
}


