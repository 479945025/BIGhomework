#ifndef SPIDER_H
#define SPIDER_H

#include<enemy.h>
#include <QGraphicsPixmapItem>
#include <QObject>


class Spider:public Enemy
{
public:
    Spider(QGraphicsItem *parent=nullptr);
};

#endif // SPIDER_H
