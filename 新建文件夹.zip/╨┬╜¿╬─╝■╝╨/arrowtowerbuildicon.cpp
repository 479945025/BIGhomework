#include "arrowtowerbuildicon.h"
#include"game.h"
#include<QtMultimedia/QMediaPlayer>

extern Game * game;
QMediaPlayer * nw = new QMediaPlayer;

ArrowTowerBuildIcon::ArrowTowerBuildIcon(QGraphicsItem * parent) : BuildTowerIcon(parent)
{
    setPixmap(QPixmap(":/scene/images/scene/1420-90.png"));
    this->setPos(1420,90);

}

void ArrowTowerBuildIcon::mousePressEvent(QGraphicsSceneMouseEvent *event){
    if (!game->build && (game->gold - 200) >= 0){
        game->build = new ArrowTower();
        game->setCursor(QString(":/tower/images/tower/mqtm_44x66.png"));
    }

}
