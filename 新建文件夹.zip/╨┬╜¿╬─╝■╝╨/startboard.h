#ifndef STARTBOARD_H
#define STARTBOARD_H

#include <QTime>
#include <QGraphicsView>
#include <QMouseEvent>
#include <QGraphicsPixmapItem>
#include<QObject>


class StartBoard:public QGraphicsView
{
public:
    StartBoard();
    void mousePressEvent(QMouseEvent *event);
    QGraphicsScene * scene;
    QGraphicsRectItem * rect;
protected:

    void drawBackground(QPainter *painter, const QRectF &rect);

};

#endif // STARTBOARD_H
