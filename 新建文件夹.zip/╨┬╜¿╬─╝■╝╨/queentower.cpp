#include "queentower.h"
#include"game.h"
#include"queentower.h"
#include"QtMath"
#include"QDebug"

extern Game * game;

QueenTower::QueenTower(QGraphicsItem * parent):Tower (parent)
{
    setPixmap(QPixmap(":/tower/images/tower/nwLv.1_110x136.png"));

    //setPixmap(QPixmap(":/png/queen.png"));
    attacking = false;
    attackRange = 250;
    damage = 80;
    money = 200;
    game->gold -= money;

    attack_desk = QPointF(0,0);
    has_target = false;

    //0.5秒发一次子弹
    QTimer * timer = new QTimer();
    connect(timer,SIGNAL(timeout()),this,SLOT(check_EnemyInRange()));
    timer->start(2000);

    //画攻击范围
    attack_area = new QGraphicsEllipseItem(0,0,attackRange*2,attackRange*2,this);
    QPen pen = QPen(Qt::DotLine);
    pen.setColor(Qt::lightGray);
    pen.setWidth(0);
    attack_area->setPen(pen);

    //画攻击范围
    QPointF offsetPoint(this->pixmap().width()*0.5,this->pixmap().height()*0.5);

    attack_area->setPos(offsetPoint + QPointF(-attackRange,-attackRange));

    bullet = new QueenBullet ();

    game->scene->addItem(bullet);
}

void QueenTower::attack_Enemy(){
    bullet->setPos(x()-200,y()-200);
    bullet->startchange();
}

void QueenTower::upgrade(){
    if(grade >= 2)
        return;

    if((game->gold - 100 * (grade+1)) >= 0){
        grade++;
        if(grade ==2){
            setPixmap(QPixmap(":/tower/images/tower/nwLv.2_120x146.png"));
            setPos(QPointF(x()-20,y()));
        }

        attackRange += 50;
        damage += 50;
        game->gold -= 200;

        game->scene->removeItem(attack_area);
        attack_area = nullptr;
        attack_area = new QGraphicsEllipseItem(0,0,attackRange*2,attackRange*2,this);

        QPen pen = QPen(Qt::DotLine);
        pen.setColor(Qt::lightGray);
        pen.setWidth(0);
        attack_area->setPen(pen);

        QPointF offsetPoint(this->pixmap().width()*0.5,this->pixmap().height()*0.5);
        attack_area->setPos(offsetPoint + QPointF(-attackRange,-attackRange));
    }
}

void QueenTower::check_EnemyInRange(){
    QList<QGraphicsItem*> colliding_items = attack_area->collidingItems();

    double closest_dist = attackRange;
    has_target = false;

    closest_pt = QPointF(0,0);

    for(size_t i = 0,n = colliding_items.size(); i < n; i++){
        Enemy * enemy = dynamic_cast<Enemy *>(colliding_items[i]);
        if(enemy){
                has_target = true;
                enemy->getDamage(damage);
                if(enemy){
                    enemy->draw();
                }
            }
     }

    if(has_target){
        if(!attacking){
            attacking = true;
            attack_Enemy();
        }
    }
    else if(bullet->changecondition){
        bullet->stopchange();
        attacking = false;
    }

}

QueenTower::~QueenTower(){
    delete bullet;
}

void QueenTower::mousePressEvent(QGraphicsSceneMouseEvent *event){
    if(game->deletebutton){
        game->scene->removeItem(game->deletebutton);
        game->deletebutton = nullptr;

        game->scene->removeItem(game->upgradebutton);
        game->upgradebutton = nullptr;
    }
    else{
        game->deletebutton = new DeleteButton();
        game->deletebutton->setPos(QPointF(x()+60,y()-55));
        game->deletebutton->tower = this;
        game->scene->addItem(game->deletebutton);

        if(game->gold - money < 0 || grade >= 2){
            game->upgradebutton = new UpgradeButton();
            game->upgradebutton->setPos(QPointF(x()-55,y()-60));
            game->upgradebutton->tower = this;
            game->upgradebutton->setPixmap(QPixmap(":/scene/images/scene/updategrey.png"));
            game->scene->addItem(game->upgradebutton);
        }
        else{
            game->upgradebutton = new UpgradeButton();
            game->upgradebutton->setPos(QPointF(x()-55,y()-60));
            game->upgradebutton->tower = this;
            game->scene->addItem(game->upgradebutton);
        }

    }

}

void QueenTower::getblack(){

}
