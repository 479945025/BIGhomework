#include "play.h"
#include "ui_play.h"
#include<QPainter>

play::play(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::play)
{
    ui->setupUi(this);
}

play::~play()
{
    delete ui;
}
void play::paintEvent(QPaintEvent *)
{
    QPixmap background(":/scene/images/scene/widget.jpg");
    QPainter painter(this);
    painter.drawPixmap(0,0,background);
}
void play::on_pushButton_clicked()
{
    this->hide();
    emit  startshow3();
}
void play::receiveplay()
{
    this->show();
}

void play::on_pushButton_2_clicked()
{
    this->hide();
    emit  xshow1();
}

void play::on_pushButton_3_clicked()
{
    this->hide();
    emit  xshow2();
}

void play::on_pushButton_4_clicked()
{
    this->hide();
    emit  xshow3();
}

void play::on_pushButton_5_clicked()
{
    this->hide();
    emit  xshow4();
}

void play::on_pushButton_6_clicked()
{
    this->hide();
    emit  xshow5();
}
