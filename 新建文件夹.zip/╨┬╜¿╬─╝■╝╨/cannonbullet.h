#ifndef CANNONBULLET_H
#define CANNONBULLET_H
#include "bullet.h"

class CannonBullet : public Bullet       
{
public:
    CannonBullet(QGraphicsItem * parent = 0);
    virtual void setInfo(QPointF _targetPos, int _damage, Enemy *_target);

public slots:
    virtual void hitTarget();

private:
    QGraphicsEllipseItem * bullet_area;
};

#endif // CANNONBULLET_H
