#ifndef LILY_H
#define LILY_H
#include<enemy.h>
#include <QGraphicsPixmapItem>
#include <QObject>

class Lily:public Enemy
{
public:
    Lily(QGraphicsItem *parent=nullptr);

};

#endif // LILY_H
