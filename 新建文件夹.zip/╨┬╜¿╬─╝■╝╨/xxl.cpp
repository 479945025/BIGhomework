#include "xxl.h"
#include "ui_xxl.h"
#include<QPainter>
xxl::xxl(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::xxl)
{
    ui->setupUi(this);
}

xxl::~xxl()
{
    delete ui;
}
void xxl::paintEvent(QPaintEvent *)
{
    QPixmap background(":/scene/images/scene/xmx.jpg");
    QPainter painter(this);
    painter.drawPixmap(0,0,background);
}
void xxl::on_pushButton_clicked()
{
    this->hide();
    emit  playshow();
}
void xxl::receivexxl()
{
    this->show();
}
