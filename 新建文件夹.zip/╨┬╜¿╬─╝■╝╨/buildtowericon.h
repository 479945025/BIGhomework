#ifndef BUILDTOWERICON_H
#define BUILDTOWERICON_H

#include <QGraphicsPixmapItem>
#include <QGraphicsSceneMouseEvent>

//多类型
class BuildTowerIcon: public QGraphicsPixmapItem{
public:
    BuildTowerIcon(QGraphicsItem * parent=0);
    virtual void mousePressEvent(QGraphicsSceneMouseEvent *event) = 0;
};

#endif // BUILDTOWERICON_H
