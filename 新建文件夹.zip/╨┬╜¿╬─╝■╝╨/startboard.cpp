#include "startboard.h"
#include"game.h"
extern Game * game;

StartBoard::StartBoard():QGraphicsView ()
{
    scene = new QGraphicsScene(this);
    scene->setSceneRect(0,0,1200,800);

    setViewportUpdateMode(QGraphicsView::FullViewportUpdate);

    setFixedSize(1200,800);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    setScene(scene);

    rect = new QGraphicsRectItem(0,0,200,200);
    scene->addItem(rect);
    rect->setBrush(QColor(Qt::black));
    rect->setPos(400,400);
}

void StartBoard::drawBackground(QPainter *painter, const QRectF &rect){
    QPixmap pixmap(":/png/startboard.jpg");
    painter->drawPixmap(rect,pixmap,QRect());
}

void StartBoard::mousePressEvent(QMouseEvent *event){
    //if(rect->contains(event->pos())){
        close();
        game = new Game();
        game->show();

}
