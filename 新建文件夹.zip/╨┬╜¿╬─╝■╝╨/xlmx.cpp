#include "xlmx.h"
#include "ui_xlmx.h"
#include<QPainter>
xlmx::xlmx(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::xlmx)
{
    ui->setupUi(this);
}

xlmx::~xlmx()
{
    delete ui;
}
void xlmx::paintEvent(QPaintEvent *)
{
    QPixmap background(":/scene/images/scene/xmx.jpg");
    QPainter painter(this);
    painter.drawPixmap(0,0,background);
}
void xlmx::on_pushButton_clicked()
{
    this->hide();
    emit  playshow();
}
void xlmx::receivexlmx()
{
    this->show();
}
