#include "slowtower.h"
#include"game.h"
#include"slowbullet.h"
#include"blacktower.h"

extern Game * game;

SlowTower::SlowTower(QGraphicsItem * parent):Tower (parent)
{
    setPixmap(QPixmap(":/tower/images/tower/mxLv.1_44x66.png"));

    attacking = false;
    attackRange = 250;
    damage = 40;
    money = 200;
    game->gold -= money;
    center_pos = QPointF(this->pixmap().width()*0.5,this->pixmap().height()*0.5);
    attack_desk = QPointF(0,0);
    has_target = false;

    slow_rate = 4;

    QTimer * timer = new QTimer();
    connect(timer,SIGNAL(timeout()),this,SLOT(check_EnemyInRange()));
    timer->start(3000);

    //画攻击范围
    attack_area = new QGraphicsEllipseItem(0,0,attackRange*2,attackRange*2,this);
    QPen pen = QPen(Qt::DotLine);
    pen.setColor(Qt::lightGray);
    pen.setWidth(0);
    attack_area->setPen(pen);

    //画攻击范围
    QPointF offsetPoint(this->pixmap().width()*0.5,this->pixmap().height()*0.5);

    attack_area->setPos(offsetPoint + QPointF(-attackRange,-attackRange));
}

void SlowTower::attack_Enemy(){
    SlowBullet * bullet = new SlowBullet ();

    bullet->setPos(x()+40,y()+40);
    bullet->setInfo(attack_desk,damage,chooseEnemy);
    bullet->setslow_rate(slow_rate);

    QLineF ln(QPointF(x()+40,y()+40),attack_desk);

    double angle = -1 * ln.angle();
    bullet->setRotation(angle);

    bullet->move();
    game->scene->addItem(bullet);
}

void SlowTower::upgrade(){
    if(grade >= 3)
        return;

    if((game->gold - 100 * (grade+1)) >= 0){
        grade++;
        if(grade ==2){
            setPixmap(QPixmap(":/tower/images/tower/mxLv.2_66x88.png"));
            setPos(QPointF(x()-20,y()));
            center_pos = QPointF(this->pixmap().width()*0.5,this->pixmap().height()*0.5);
        }
        else if(grade == 3){
            setPixmap(QPixmap(":/tower/images/tower/mxLv.3_110x136.png"));
            setPos(QPointF(x()-25,y()));
            center_pos = QPointF(this->pixmap().width()*0.5,this->pixmap().height()*0.5);
        }

        attackRange += 50;
        damage += 50;
        game->gold -= 200;

        game->scene->removeItem(attack_area);
        attack_area = nullptr;
        attack_area = new QGraphicsEllipseItem(0,0,attackRange*2,attackRange*2,this);

        QPen pen = QPen(Qt::DotLine);
        pen.setColor(Qt::lightGray);
        pen.setWidth(0);
        attack_area->setPen(pen);

        QPointF offsetPoint(this->pixmap().width()*0.5,this->pixmap().height()*0.5);
        attack_area->setPos(offsetPoint + QPointF(-attackRange,-attackRange));
    }
}

void SlowTower::getblack(){
    black = 1;

    BlackTower * blacktower = new BlackTower();
    blacktower->setPos(QPointF(x()-40,y()));
    blacktower->setPixmap(QPixmap(":/tower/images/tower/gmx_110x136.png"));

    game->scene->addItem(blacktower);
    game->scene->removeItem(this);
    delete this;
}
