#ifndef ARROWTOWERBUILDICON_H
#define ARROWTOWERBUILDICON_H
#include"buildtowericon.h"
#include"arrowbullet.h"
#include"arrowtower.h"

class ArrowTowerBuildIcon:public BuildTowerIcon
{
public:
    ArrowTowerBuildIcon(QGraphicsItem * parent=0);
    virtual void mousePressEvent(QGraphicsSceneMouseEvent *event);

};

#endif // ARROWTOWERBUILDICON_H
