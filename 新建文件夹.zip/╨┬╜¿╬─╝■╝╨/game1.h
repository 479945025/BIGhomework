#ifndef GAME1_H
#define GAME1_H
#include"game.h"
#include"game2.h"

class Game1:public Game
{
public:
    Game1();
    void setTowerPosition();
    void draw_Background(QPainter * painter);
public slots:
    void drawEnemy();
protected:
    Game2 * game2;
    void drawBackground(QPainter *painter, const QRectF &rect);
};

#endif // GAME1_H
