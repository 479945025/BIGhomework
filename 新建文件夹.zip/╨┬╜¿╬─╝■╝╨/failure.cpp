#include "failure.h"
#include "ui_failure.h"
#include <QPainter>
#include"start.h"

extern MainWindow * window;

failure::failure(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::failure)
{
    ui->setupUi(this);
}

failure::~failure()
{
    delete ui;
}
void failure::paintEvent(QPaintEvent *)
{
    QPixmap background(":/scene/images/scene/failure.jpg");
    QPainter painter(this);
    painter.drawPixmap(0,0,background);
}
void failure::on_pushButton_clicked()
{
    this->hide();
    emit  showmainwindow();
}
void failure::receivefailure()
{
    this->show();
}
