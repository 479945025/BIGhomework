#ifndef START_H
#define START_H
#include <QDialog>
#include<QtMultimedia/QMediaPlayer>


namespace Ui {
class start;
}

class start : public QDialog
{
    Q_OBJECT

public:
    explicit start(QWidget *parent = nullptr);
    ~start();
    void paintEvent(QPaintEvent *);

private slots:
    void receiveshow();
    void receiveshow1();
    void receiveshow2();
    void receiveshow3();
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();

signals:
    void showmainwindow();
    void showstory();
    void showpeople();
    void showplay();
private:
    Ui::start *ui;
};

#endif // START_H
