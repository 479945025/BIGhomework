#ifndef STARTTOUCH_H
#define STARTTOUCH_H


class StartTouch
{
public:
    StartTouch();
};

#endif // STARTTOUCH_H