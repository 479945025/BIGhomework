#include "story.h"
#include "ui_story.h"
#include<QPainter>
#include<QMovie>
#include<QLabel>
#include<QtMultimedia/QMediaPlayer>

extern QMediaPlayer * player;
extern QMediaPlayer * playerstory;

story::story(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::story)
{
    ui->setupUi(this);
}

story::~story()
{
    delete ui;
}
void story::paintEvent(QPaintEvent *)
{
    QPixmap background(":/scene/images/scene/scene.jpg");
    QPainter painter(this);
    painter.drawPixmap(0,0,background);
}
void story::on_pushButton_clicked()
{
    this->hide();
    player->play();
    playerstory->stop();

    label->close();
    emit  startshow1();
}

void story::receivestory()
{
    this->show();

    QMovie * movie = new QMovie(":/scene/images/scene/story.gif");
    movie->setSpeed(100);
        label = new QLabel;
        label->setMovie(movie);
        movie->start();
        label->show();

}

