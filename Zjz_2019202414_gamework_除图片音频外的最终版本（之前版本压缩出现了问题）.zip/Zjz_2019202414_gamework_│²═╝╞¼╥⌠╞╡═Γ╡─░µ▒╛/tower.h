#ifndef TOWER_H
#define TOWER_H

#include <QGraphicsPixmapItem>
#include <QGraphicsPolygonItem>
#include <QGraphicsItem>
#include <QPointF>
#include <QObject>
#include <QTimer>
#include "enemy.h"
#include "bullet.h"
#include"towerposition.h"

class Tower:public QObject, public QGraphicsPixmapItem{
    Q_OBJECT
public:
    Tower(QGraphicsItem * parent = 0);
    ~Tower();

    int getmoney();
    double distanceto(QGraphicsItem * Item);

    bool testblack();

    virtual void attack_Enemy() = 0 ;
    virtual void upgrade() = 0;
    virtual void getblack() = 0;
    virtual void mousePressEvent(QGraphicsSceneMouseEvent *event);

    void target_Killed();
    void lostSightOfEnemy();
    void chooseEnemyForAttack(Enemy *enemy);
    void getTowerPosition(TowerPosition * _towerposition);

    TowerPosition * towerposition;
public slots:
    virtual void check_EnemyInRange();

protected:
    int money;
    int attackRange;
    int damage;
    int grade;

    double closestdist;

    bool attacking;
    bool black;

    //static const QSize fixedSize;

    bool has_target;
    QPointF attack_desk;
    QPointF closest_pt;  
    QPointF center_pos;

    Enemy * chooseEnemy;
    QGraphicsEllipseItem * attack_area;
};

#endif // TOWER_H
