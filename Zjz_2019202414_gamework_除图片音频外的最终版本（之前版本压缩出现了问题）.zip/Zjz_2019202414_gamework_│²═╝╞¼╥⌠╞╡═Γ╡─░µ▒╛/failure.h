#ifndef FAILURE_H
#define FAILURE_H

#include <QWidget>
#include"mainwindow.h"
namespace Ui {
    class failure;
}

class failure : public QWidget
{
    Q_OBJECT

public:
    explicit failure(QWidget *parent = nullptr);
    ~failure();
    void paintEvent(QPaintEvent *);

private slots:
    void on_pushButton_clicked();
    void receivefailure();
signals:
    void showmainwindow();
private:
    Ui::failure *ui;
};

#endif // FAILURE_H
