#ifndef GUNALA_H
#define GUNALA_H

#include<enemy.h>
#include <QGraphicsPixmapItem>
#include <QObject>

class Gunala:public Enemy
{
    Q_OBJECT
public:
    Gunala(QGraphicsItem *parent=nullptr);
    virtual void getRemoved();
private:
    int life=3;
    QGraphicsEllipseItem * black_area;
public slots:
    void check_TowerInRange();
};

#endif // GUNALA_H
