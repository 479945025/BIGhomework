#include"towerposition.h"
#include"mainwindow.h"
#include <QPainter>
#include <QColor>
#include <QTimer>
#include <QVector2D>
#include <QtMath>
#include "tower.h"
#include <QPixmap>
#include <QVector>
#include <QPolygonF>
#include <QPointF>
#include <QLineF>
#include <QGraphicsRectItem>
#include<QSize>

const QSize TowerPosition::fixedSize(66,44);

TowerPosition::TowerPosition(QGraphicsItem * parent):QObject(),QGraphicsPixmapItem (parent){

}

const QPointF TowerPosition::centerPos() const
{
    QPointF offsetPoint(fixedSize.width()/2,fixedSize.height()/2);
    return pos()+offsetPoint;
}

bool TowerPosition::Point_Place (const QPointF & pos) const{
    bool ContainX = (x()-fixedSize.width()) < pos.x() && pos.x() < (x() + 2 * fixedSize.width());
    bool ContainY = (y()-fixedSize.width()) < pos.y() && pos.y() < (y() + 2 * fixedSize.height());
    return ContainX && ContainY;
}

void TowerPosition::setTower_Exist(bool _Tower_Exist){
    Tower_Exist = _Tower_Exist;
}

bool TowerPosition::testTower_Exist(){
    return Tower_Exist;
}
