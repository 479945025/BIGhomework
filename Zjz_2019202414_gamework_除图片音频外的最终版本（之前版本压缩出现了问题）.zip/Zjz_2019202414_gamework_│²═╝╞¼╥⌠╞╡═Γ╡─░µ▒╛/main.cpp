#include "mainwindow.h"
#include <QApplication>
#include"game.h"
#include"start.h"
#include<thread>
#include"story.h"
#include"people.h"
#include"play.h"
#include "xlm.h"
#include "xlmx.h"
#include "xlmq.h"
#include "xxl.h"
#include "xnw.h"
#include"game1.h"
#include"game2.h"
#include"game3.h"
#include"enemy.h"
#include"victory.h"
#include "failure.h"
Game * game;

MainWindow * window;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    start st;
    MainWindow mw;
    story ins;
    people pe;
    play pl;
    xlm lm;
    xlmx lmx;
    xlmq lmq;
    xxl xl;
    xnw nw;
    Enemy en;
    victory vic;
    failure fail;
    st.show();
    mw.hide();
    QObject::connect(&st,SIGNAL(showmainwindow()),&mw,SLOT(receivechoose()));
    QObject::connect(&mw,SIGNAL(startshow()),&st,SLOT(receiveshow()));
    QObject::connect(&st,SIGNAL(showstory()),&ins,SLOT(receivestory()));
    QObject::connect(&ins,SIGNAL(startshow1()),&st,SLOT(receiveshow1()));
    QObject::connect(&st,SIGNAL(showpeople()),&pe,SLOT(receivepeople()));
    QObject::connect(&pe,SIGNAL(startshow2()),&st,SLOT(receiveshow2()));
    QObject::connect(&st,SIGNAL(showplay()),&pl,SLOT(receiveplay()));
    QObject::connect(&pl,SIGNAL(startshow3()),&st,SLOT(receiveshow3()));


    QObject::connect(&pl,SIGNAL(xshow1()),&lm,SLOT(receivexlm()));
    QObject::connect(&lm,SIGNAL(playshow()),&pl,SLOT(receiveplay()));
    QObject::connect(&pl,SIGNAL(xshow2()),&lmx,SLOT(receivexlmx()));
    QObject::connect(&lmx,SIGNAL(playshow()),&pl,SLOT(receiveplay()));
    QObject::connect(&pl,SIGNAL(xshow3()),&lmq,SLOT(receivexlmq()));
    QObject::connect(&lmq,SIGNAL(playshow()),&pl,SLOT(receiveplay()));
    QObject::connect(&pl,SIGNAL(xshow4()),&xl,SLOT(receivexxl()));
    QObject::connect(&xl,SIGNAL(playshow()),&pl,SLOT(receiveplay()));
    QObject::connect(&pl,SIGNAL(xshow5()),&nw,SLOT(receivexnw()));
    QObject::connect(&nw,SIGNAL(playshow()),&pl,SLOT(receiveplay()));
    QObject::connect(&pl,SIGNAL(xshow5()),&nw,SLOT(receivexnw()));

    QObject::connect(&vic,SIGNAL(showmainwindow()),&mw,SLOT(receivechoose()));
    QObject::connect(&fail,SIGNAL(showmainwindow()),&mw,SLOT(receivechoose()));
    //QObject::connect(&en,SIGNAL(showfailure()),&fail,SLOT(receivefailure()));

    //game1 = new MainWindow();
    //game1->show();

    return a.exec();
}
