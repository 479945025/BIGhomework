#include "xlmq.h"
#include "ui_xlmq.h"
#include<QPainter>
xlmq::xlmq(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::xlmq)
{
    ui->setupUi(this);
}

xlmq::~xlmq()
{
    delete ui;
}
void xlmq::paintEvent(QPaintEvent *)
{
    QPixmap background(":/scene/images/scene/xmx.jpg");
    QPainter painter(this);
    painter.drawPixmap(0,0,background);
}
void xlmq::on_pushButton_clicked()
{
    this->hide();
    emit  playshow();
}
void xlmq::receivexlmq()
{
    this->show();
}
