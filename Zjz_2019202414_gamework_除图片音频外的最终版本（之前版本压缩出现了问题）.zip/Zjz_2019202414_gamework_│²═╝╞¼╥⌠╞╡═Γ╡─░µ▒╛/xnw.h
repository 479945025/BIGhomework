#ifndef XNW_H
#define XNW_H

#include <QWidget>

namespace Ui {
class xnw;
}

class xnw : public QWidget
{
    Q_OBJECT

public:
    explicit xnw(QWidget *parent = nullptr);
    ~xnw();
    void paintEvent(QPaintEvent *);


private slots:
    void on_pushButton_clicked();
    void receivexnw();
signals:
    void playshow();

private:
    Ui::xnw *ui;
};

#endif // XNW_H
