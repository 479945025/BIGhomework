#ifndef ELF_H
#define ELF_H

#include<enemy.h>
#include <QGraphicsPixmapItem>
#include <QObject>

class elf:public Enemy
{
public:
    elf(QGraphicsItem *parent=nullptr);

};

#endif // ELF_H
