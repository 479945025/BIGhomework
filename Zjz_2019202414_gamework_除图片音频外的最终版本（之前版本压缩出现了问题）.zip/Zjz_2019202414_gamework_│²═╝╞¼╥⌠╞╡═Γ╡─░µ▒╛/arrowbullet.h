#ifndef ARROWBULLET_H
#define ARROWBULLET_H
#include "bullet.h"

class ArrowBullet : public Bullet
{
public:
    ArrowBullet(QGraphicsItem * parent = 0);
    virtual void setInfo(QPointF _targetPos, int _damage, Enemy *_target);
};

#endif // ARROWBULLET_H
