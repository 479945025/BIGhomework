#ifndef GREENBULLET_H
#define GREENBULLET_H
#include"bullet.h"

class GreenBullet: public Bullet
{
public:
    GreenBullet(QGraphicsItem * parent = 0);
    virtual void setInfo(QPointF _targetPos, int _damage, Enemy *_target);
};

#endif // GREENBULLET_H
