#include "game1.h"
#include "game2.h"
#include<QGraphicsScene>
#include<qdebug.h>
#include"xiaoyue.h"
#include"victory.h"
#include<QtMultimedia/QMediaPlayer>

extern QMediaPlayer * player1;
extern QMediaPlayer * player2;
extern Game * game;

Game1::Game1():Game ()
{
    playerHp = 10;
    gold = 800;
    currentEnemyNum = 0;

    scene = new QGraphicsScene(this);
    scene->setSceneRect(0,0,1884,1200);

    QPixmap map(":/scene/images/scene/background1.jpg");

    points_1<<QPoint(1400,320)
           <<QPoint(650,320)
             <<QPoint(600,420)
           <<QPoint(650,520)
           <<QPoint(950,520)
             <<QPoint(1000,650)
           <<QPoint(950,770)
           <<QPoint(430,770)
           <<QPoint(230,900)
           <<QPoint(0,900);
    points_2<<QPoint(1400,950)
             <<QPoint(1000,950)
             <<QPoint(800,770)
             <<QPoint(460,770)
             <<QPoint(230,900)
             <<QPoint(0,900);
    QPainter painter(&map);

    setScene(scene);

    setTowerPosition();

    setViewportUpdateMode(QGraphicsView::FullViewportUpdate);

    deletebutton = nullptr;
    upgradebutton = nullptr;
    cursor = nullptr;
    build = nullptr;

    setMouseTracking(true);

    setFixedSize(1884,1200);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    QTimer *timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(drawEnemy()));
    timer->start(1000);

}
void Game1::drawEnemy(){
    if(waves==1&&enemyNum<6){
        Butterfly *butterfly = new Butterfly();
        scene->addItem(butterfly);
        enemyNum++;
        currentEnemyNum++;
        if(enemyNum==6){
            enemyNum=0;
            waves++;
            nextwave=0;
        }
    }

    qDebug()<<"enemynum"<<enemyNum;
    qDebug()<<"currentenemynum"<<currentEnemyNum;
    if(waves==2&&currentEnemyNum==0) nextwave=1;

    if(waves==2&&nextwave){
        Butterfly *butterfly = new Butterfly();
        scene->addItem(butterfly);
        enemyNum++;
        currentEnemyNum++;
        if(enemyNum==7){
            enemyNum=0;
            waves++;
            nextwave=0;
        }
    }
    if(waves==3&&currentEnemyNum==0) nextwave=1;
    if(waves==3&&nextwave){
        Butterfly *butterfly = new Butterfly();
        scene->addItem(butterfly);
        enemyNum++;currentEnemyNum++;
        if(enemyNum==8){
            enemyNum=0;
            waves++;
            nextwave=0;
        }
    }

    if(waves==4&&currentEnemyNum==0) nextwave=1;
    if(waves==4&&nextwave){
        if(enemyNum<6){
            Butterfly *butterfly = new Butterfly();
            scene->addItem(butterfly);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=6&&enemyNum<10){
            Spider *spider = new Spider();
            scene->addItem(spider);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum==10){
            enemyNum=0;
            waves++;
            nextwave=0;
        }
    }
    if(waves==5&&currentEnemyNum==0) nextwave=1;
    if(waves==5&&nextwave){
        if(enemyNum<7){
            Butterfly *butterfly = new Butterfly();
            scene->addItem(butterfly);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=7&&enemyNum<12){
            Spider *spider = new Spider();
            scene->addItem(spider);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum==12){
            enemyNum=0;
            waves++;
            nextwave=0;
        }
    }
    if(waves==6&&currentEnemyNum==0) nextwave=1;
    if(waves==6&&nextwave){
        if(enemyNum<8){
            Butterfly *butterfly = new Butterfly();
            scene->addItem(butterfly);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=8&&enemyNum<14){
            Spider *spider = new Spider();
            scene->addItem(spider);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum==14){
            enemyNum=0;
            waves++;
            nextwave=0;
        }
    }
    if(waves==7&&currentEnemyNum==0) nextwave=1;
    if(waves==7&&nextwave){
        if(enemyNum<4){
            Butterfly *butterfly = new Butterfly();
            scene->addItem(butterfly);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=4&&enemyNum<8){
            Spider *spider = new Spider();
            scene->addItem(spider);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=8&&enemyNum<12){
            elf *_elf = new elf();
            scene->addItem(_elf);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum==12){
            enemyNum=0;
            waves++;
            nextwave=0;
        }
    }
    if(waves==8&&currentEnemyNum==0) nextwave=1;
    if(waves==8&&nextwave){
        if(enemyNum<5){
            Butterfly *butterfly = new Butterfly();
            scene->addItem(butterfly);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=5&&enemyNum<10){
            Spider *spider = new Spider();
            scene->addItem(spider);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=10&&enemyNum<15){
            elf *_elf = new elf();
            scene->addItem(_elf);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum==15){
            enemyNum=0;
            waves++;
            nextwave=0;
        }
    }
    if(waves==9&&currentEnemyNum==0) nextwave=1;
    if(waves==9&&nextwave){
        if(enemyNum<6){
            Butterfly *butterfly = new Butterfly();
            scene->addItem(butterfly);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=6&&enemyNum<12){
            Spider *spider = new Spider();
            scene->addItem(spider);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum>=12&&enemyNum<18){
            elf *_elf = new elf();
            scene->addItem(_elf);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum==18){
            enemyNum=0;
            waves++;
            nextwave=0;
        }
    }
    if(waves==10&&currentEnemyNum==0) nextwave=1;
    if(waves==10&&nextwave){
        if(enemyNum<8){
            elf *_elf = new elf();
            scene->addItem(_elf);
            enemyNum++;currentEnemyNum++;
        }
        if(enemyNum==8){
            Lily *lily = new Lily();
            currentEnemyNum++;
            scene->addItem(lily);
            waves++;
        }
    }

    if(waves==11&&currentEnemyNum==0&&playerHp>0){
        player1->stop();
        delete this;

        player2->setMedia(QUrl::fromLocalFile("C:/Cigarette/MyTowerDefense/music/Game2.mp3"));
        player2->setVolume(30);
        player2->play();

        game = new Game2();
        game->show();

        return;
    }

}


void Game1::drawBackground(QPainter *painter, const QRectF &rect){
    QPixmap pixmap(":/scene/images/scene/background1.jpg");
    painter->drawPixmap(rect,pixmap,QRect());
    draw_Background(painter);
}

void Game1::setTowerPosition(){
    QPoint pos[] =
    {
        QPoint(330,185),
        QPoint(420,185),
        QPoint(510,185),

        QPoint(215,290),
        QPoint(305,290),
        QPoint(395, 290),

        QPoint(230,405),
        QPoint(320, 405),
        QPoint(470, 405),
        QPoint(200,190),
        QPoint(95,355)
    };

    int len	= sizeof(pos) / sizeof(pos[0]);

    //不知道出了什么奇怪的bug要乘2倍多？？
    for(int i = 0;i<len; i++){
        pos[i] *= 2.1;
    }

    for (int i = 0; i < len; ++i){
        TowerPositionsList.push_back(new TowerPosition());
        TowerPositionsList[i]->setPos(pos[i]);
        TowerPositionsList[i]->setPixmap(QPixmap(":/tower/images/tower/imagek1.png"));
        scene->addItem(TowerPositionsList[i]);
    }

}

void Game1::draw_Background(QPainter * painter){
    QPixmap m_extensive(":/scene/images/scene/extensive.jpg");
    painter->drawPixmap(1400, 0, 484, 1200 ,m_extensive);    //右边扩展部分的总背景板

    QPixmap m_heroes(":/scene/images/scene/heroes1.png");
    painter->drawPixmap(1400, 0, 484, 423, m_heroes);    //塔类选择栏

    QPixmap m_waves(":/scene/images/scene/stage.png");
    painter->drawPixmap(1400, 423, 484, 147, m_waves);    //关卡数目

    QPixmap m_hp(":/scene/images/scene/waves.png");
    painter->drawPixmap(1400, 570, 484, 147, m_hp);    //敌人的波数

    QPixmap m_gold(":/scene/images/scene/gold.png");
    painter->drawPixmap(1400, 717, 484, 147, m_gold);    //金币数量

    QPixmap m_heart(":/scene/images/scene/heart.png");
    painter->drawPixmap(1590, 925, 207, 178, m_heart);    //七彩之心

    painter->setPen(QPen(Qt::red));
    painter->drawText(QRect(1600, 493, 1200, 500), QString("HP : %1").arg(playerHp));    //关卡数目

    painter->setPen(QPen(Qt::red));
    painter->drawText(QRect(1590, 643, 1200, 500), QString("WAVE : %1").arg(waves));    //敌人波数

    painter->setPen(QPen(Qt::red));
    painter->drawText(QRect(1590, 793, 100, 500), QString("GOLD : %1").arg(gold));    //金币数目

    BuildTowerIcon * aic = new ArrowTowerBuildIcon();
    scene->addItem(aic);

    BuildTowerIcon * cic = new CannonTowerBuildIcon();
    scene->addItem(cic);

    BuildTowerIcon * sic = new  SlowTowerBuildIcon();
    scene->addItem(sic);

}
