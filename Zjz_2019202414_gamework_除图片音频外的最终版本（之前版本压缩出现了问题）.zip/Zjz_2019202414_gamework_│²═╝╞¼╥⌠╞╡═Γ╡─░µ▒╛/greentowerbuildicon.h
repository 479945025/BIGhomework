#ifndef GREENTOWERBUILDICON_H
#define GREENTOWERBUILDICON_H
#include"buildtowericon.h"
#include"greenbullet.h"
#include"greentower.h"

class GreenTowerBuildIcon:public BuildTowerIcon
{
public:
    GreenTowerBuildIcon(QGraphicsItem * parent = 0);
    virtual void mousePressEvent(QGraphicsSceneMouseEvent *event);
};

#endif // GREENTOWERBUILDICON_H
