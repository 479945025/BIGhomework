#ifndef XLMQ_H
#define XLMQ_H

#include <QWidget>

namespace Ui {
class xlmq;
}

class xlmq : public QWidget
{
    Q_OBJECT

public:
    explicit xlmq(QWidget *parent = nullptr);
    ~xlmq();
    void paintEvent(QPaintEvent *);


private slots:
    void on_pushButton_clicked();
    void receivexlmq();
signals:
    void playshow();
private:
    Ui::xlmq *ui;
};

#endif // XLMQ_H
