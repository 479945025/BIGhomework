#ifndef BULLET_H
#define BULLET_H

#include <QGraphicsPixmapItem>
#include <QObject>
#include <QGraphicsItem>

class Enemy;

class Bullet: public QObject, public QGraphicsPixmapItem{
    Q_OBJECT
    Q_PROPERTY(QPointF b_currentPos READ currentPos WRITE setCurrentPos)

public:
    Bullet(QGraphicsItem * parent=0);

    virtual void setInfo(QPointF _targetPos = QPointF(0,0),
                 int _damage = 0,Enemy * _target = 0) = 0;

    void setCurrentPos(QPointF pos);
    void move();

    QPointF currentPos() const;


public slots:
    virtual void hitTarget();

protected:
    int damage;

    Enemy * target;

    QPointF startPos;
    QPointF targetPos;
    QPointF b_currentPos;  
};

#endif // BULLET_H
