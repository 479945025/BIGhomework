#ifndef QUEENBULLET_H
#define QUEENBULLET_H
#include "bullet.h"
#include"time.h"
#include <QGraphicsPixmapItem>
#include <QObject>
#include <QGraphicsItem>

class QueenBullet: public QObject,public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    QueenBullet(QGraphicsItem * parent = 0);
    int count;
    QTimer * timer;
    void startchange();
    void stopchange();
    bool changecondition;
public slots:
    void changepictures();
};

#endif // QUEENBULLET_H
