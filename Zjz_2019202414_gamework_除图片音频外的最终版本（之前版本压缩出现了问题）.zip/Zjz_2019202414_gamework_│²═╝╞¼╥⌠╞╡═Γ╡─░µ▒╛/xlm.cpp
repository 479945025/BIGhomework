#include "xlm.h"
#include "ui_xlm.h"
#include<QPainter>
xlm::xlm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::xlm)
{
    ui->setupUi(this);
}

xlm::~xlm()
{
    delete ui;
}

void xlm::paintEvent(QPaintEvent *)
{
    QPixmap background(":/scene/images/scene/xmx.jpg");
    QPainter painter(this);
    painter.drawPixmap(0,0,background);
}
void xlm::on_pushButton_clicked()
{
    this->hide();
    emit  playshow();
}
void xlm::receivexlm()
{
    this->show();
}
